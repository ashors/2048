Anna Shors
ashors
Project 1
MW 12:30 lab

This project is a version of the 2048 game. Tiles are moved by pressing a, s, d, or w. If a user wishes to
quit or restart, he/she can press q or r, respectively. Once a user fills the board and there are no more possible moves, 
the game ends after a user attempts to make another move. When the game ends, the number of moves is printed along
with the highest tile.